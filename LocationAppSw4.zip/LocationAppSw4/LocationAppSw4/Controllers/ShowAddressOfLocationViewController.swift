//
//  ShowAddressOfLocationViewController.swift
//  LocationAppSw4
//
//  Created by Ingo Ngoyama on 2/20/18.
//  Copyright © 2018 IngoNgoyama. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation // need to work with the CLManager

//make class comply to CLLocationManagerDelegate and MKMapViewDelegate
class ShowAddressOfLocationViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

	@IBOutlet weak var mapView: MKMapView!
	@IBOutlet weak var addressLabel: UILabel!
	
	//COPY OVER THE CODE FROM MyLocationVC And cut out the unseen code XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	var locationManager: CLLocationManager = CLLocationManager()
	
	var oldLocation: CLLocation!
	
	override func viewDidLoad() {
		super.viewDidLoad()
		
		self.title = "Show Address"
		
		
		
		
		locationManager.desiredAccuracy = kCLLocationAccuracyBest
		locationManager.delegate = self
		locationManager.requestWhenInUseAuthorization()
		locationManager.startUpdatingLocation()
		
		locationManager.distanceFilter = 5
		mapView.showsUserLocation = true
		mapView.delegate = self
	}
	
	func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
		
		//set region
		let region = MKCoordinateRegionMakeWithDistance((locations.last?.coordinate)!, 5000, 5000)
		
		print(locations.last?.coordinate) 
		mapView.setRegion(region, animated: true)
	
	}
	
	
	//error handler
	func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) { //display any errors
		print(error)
	}

	func mapView(_ mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
		//our current location will show now
		//print(mapView.centerCoordinate) // TEST<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
		
		
		
		// reverse geocode below......................................................
		//get coordinates
		let location = CLLocation(latitude: mapView.centerCoordinate.latitude , longitude: mapView.centerCoordinate.longitude)
		
		// make a geoCoder instance to manage it
		let geoCoder = CLGeocoder()
		
		//reverse the coding to get an address
		geoCoder.reverseGeocodeLocation(location) { (placemarks, error) in
			if error != nil{
				print(error)
				return
			}
			else
			{
				if (placemarks?.count)! > 0 // if there are 1 or more placemarks then...
				{
					let singlePlacemark = placemarks![0]
					//print(singlePlacemark) //TEST<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
					
					//get thet address
					let addressDict = singlePlacemark.addressDictionary // this is a feature that holds the address for all coordinates
					
					print(addressDict) // to view all the info in this feature
					
					//now we can get our values from the dictionary
					
					let address = addressDict!["SubThoroughfare"] ?? "" // adresss number
					let street = addressDict!["Thoroughfare"] ?? "" 	//street
					let city = addressDict!["City"] ?? ""
					let state = addressDict!["State"] ?? ""
					let zip = addressDict!["ZIP"] ?? ""
					let country = addressDict!["Country"] ?? ""

					
					//put together the adress with concatonation and display un the address label
					self.addressLabel.text = " \(address) \(street) \(city) \(state) \(zip) \(country)"
					
				}
			}
		}
	}

}
























