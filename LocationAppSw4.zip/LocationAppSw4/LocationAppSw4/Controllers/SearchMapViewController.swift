//
//  SearchMapViewController.swift
//  LocationAppSw4
//
//  Created by Ingo Ngoyama on 2/21/18.
//  Copyright © 2018 IngoNgoyama. All rights reserved.
//

import UIKit
import MapKit


class SearchMapViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

	
	@IBOutlet weak var searchTextField: UITextField!
	@IBOutlet weak var mapView: MKMapView!
	
	
	
	
    override func viewDidLoad() {
        super.viewDidLoad()
		
		self.title = "Search Map" // title of this view

    }

	@IBAction func textfieldEndExit(_ sender: Any) {
		
		func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
			
			//set region
			let region = MKCoordinateRegionMakeWithDistance((locations.last?.coordinate)!, 1500, 1500)
			
			print(locations.last?.coordinate) // Test to see how often refreshed<<<<<<<<<<<
			mapView.setRegion(region, animated: true)
		}
		
		mapView.removeAnnotations(mapView.annotations)// this will clear map for next search
		
		let searchRequest = MKLocalSearchRequest() // can query mapkit using a naturallanguage(human input)
		searchRequest.naturalLanguageQuery = searchTextField.text ?? "Pizza" // use textfield as input
		
		searchRequest.region = mapView.region // search in the area you are currently in
	
		let mapSearch = MKLocalSearch(request: searchRequest)
		
		mapSearch.start { (searchResponse, error) in
			if error != nil{ //check for errors
				print(error)
				return
			}
			else if searchResponse!.mapItems.count == 0 //check for response
			{
					print("No result found!")
			}
			else
			{
				for singleItem in searchResponse!.mapItems{
					//print(singleItem) // TEST RUN<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
					
					//now we can will display info on the map
					let annotation = MKPointAnnotation()
					annotation.coordinate = singleItem.placemark.coordinate
					annotation.title = singleItem.name ?? "No name"
					annotation.subtitle = singleItem.phoneNumber ?? "No number"
					
					self.mapView.addAnnotation(annotation)
					
					//TESTRUN<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
					
				}
			}
		}
		
		searchTextField.resignFirstResponder() // turns keyboard off
		
	}
	
}



