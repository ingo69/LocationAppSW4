//
//  MyLocationViewController.swift
//  LocationAppSw4
//
//  Created by Ingo Ngoyama on 2/19/18.
//  Copyright © 2018 IngoNgoyama. All rights reserved.
//

import UIKit
import MapKit

class MyLocationViewController: UIViewController, CLLocationManagerDelegate {

	@IBOutlet weak var mapView: MKMapView!
	@IBOutlet weak var distanceLabel: UILabel!
	
	// need an instance of CLLocationManager to get to more features of Maps
	var locationManager: CLLocationManager = CLLocationManager()
	
	var oldLocation: CLLocation!  //to have a point of reference for distance traveled. value wont change once set so we force unwrap.
	
	
	
	
	override func viewDidLoad() {
        super.viewDidLoad()
		
		self.title = "My Location" // title of this view
		
		
		
		oldLocation = nil // initial value of oldLocation
		
		
		locationManager.desiredAccuracy = kCLLocationAccuracyBest
		locationManager.delegate = self
		locationManager.requestWhenInUseAuthorization()
		locationManager.startUpdatingLocation() // good but refreshes a little to much use next line instead
		//locationManager.requestLocation()//one time loc request.must make func locationManager(..didfail..)further below
		locationManager.distanceFilter = 50 // for a moving person
		
		
		
		
		
		
		
		
		
		
		mapView.showsUserLocation = true
		
    }

	
	

	
	
	
	func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
		
		//set region
		let region = MKCoordinateRegionMakeWithDistance((locations.last?.coordinate)!, 1500, 1500)
		
		print(locations.last?.coordinate) // Test to see how often refreshed<<<<<<<<<<<
		
		mapView.setRegion(region, animated: true)
		//TestRun
		
	
		
		if oldLocation == nil{
			oldLocation = locations.first // .first is the same as [0] in arrays. (preset to nil)
		}
		let newLocation =  locations.last // gets us the last reported coordinate as the new point to measure to
		let distance = newLocation?.distance(from: oldLocation) // measures the didstance btw the two points
		
		if let distance = distance{ //we have to unwrap because distane is an optional
			distanceLabel.text = String(format: "%0.1f meters", distance)
		}
		
		
//optional Drop pin at current  Location@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
/*
		// Drop a pin at user's Current Location
		let myAnnotation: MKPointAnnotation = MKPointAnnotation()
		myAnnotation.coordinate = CLLocationCoordinate2DMake(newLocation!.coordinate.latitude, newLocation!.coordinate.longitude);
		myAnnotation.title = "Current location"
		mapView.addAnnotation(myAnnotation)
		
		
		func locationManager(manager: CLLocationManager, didFailWithError error: NSError)
		{
			print("Error \(error)")
		}
		
		//TestRun
*/
	}
	
	func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) { //display any errors
		print(error) 
	}
	

	
	
	
	
	
	
	
	
	
	
}
