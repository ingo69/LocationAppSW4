//
//  SearchAddressViewController.swift
//  LocationAppSw4
//
//  Created by Ingo Ngoyama on 2/19/18.
//  Copyright © 2018 IngoNgoyama. All rights reserved.
//

import UIKit
import MapKit

class SearchAddressViewController: UIViewController, UITextFieldDelegate, MKMapViewDelegate,  CLLocationManagerDelegate{
// VC Objective: to type in an address and have its location displayed on the map

	
	
	@IBOutlet weak var addressTextfield: UITextField!
	
	@IBOutlet weak var mapView: MKMapView!
	
	
    override func viewDidLoad() {
        super.viewDidLoad()
		
		self.title = "Address Search" // title of this view
		
		addressTextfield.delegate = self
		
    }

	
	
	
	func textFieldShouldReturn(_ textField: UITextField) -> Bool {
		
		let addressGeocoder = CLGeocoder() //creata a geocoder
		
		addressGeocoder.geocodeAddressString(addressTextfield.text!) { (placemarks, error)/* completionhandler*/ in
			//once the completionhandler gives the placemarks or the error it is now processed correspondingly
			
			if error != nil
			{
				print(error)
				return
			}
			
			if let placemarks = placemarks{
				let firstPlacemark = placemarks[0]// you may get more than one. we'll just use the first one for now
				
				//print(firstPlacemark)      //TESTRUN<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
				
				// make annotations
				let annotation = MKPointAnnotation()
				//annotation.title = "this is the title"
				//annotation.subtitle = "Subtitle- 929387"
				
				if let location = firstPlacemark.location{
					annotation.coordinate = location.coordinate
					self.mapView.addAnnotation(annotation)
					
					//this cstm annotation will autoSet the zoom so no need  to set the region further down in our code.
					//but it will also show all the annotations in the region which you may or may not want.
					self.mapView.showAnnotations([annotation], animated: true)
					
					//thus with the above code we need to make the searched for annot annotation stand outfrom  the rest of the annotations by auto show the titles
					self.mapView.selectAnnotation(annotation, animated: true) // input our queried annotation
					
					
					//print(firstPlacemark)
					//TESTRUN<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
				}
				

				
				// with the above advanced annotation we dont have to manually set the autozoom
				/*let region = MKCoordinateRegionMakeWithDistance(annotation.coordinate, 250, 250)
				
				self.mapView.setRegion(region, animated: true)
				*/
				
				
				//TESTRUN<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
			}
		}
		
	
		
		textField.resignFirstResponder() // keybrd dismissal
		return true
	}
	

	
	@IBAction func textfieldEndExit(_ sender: Any) {
		
		
		mapView.removeAnnotations(mapView.annotations)// this will clear map for next search
		
		let searchRequest = MKLocalSearchRequest() // can query mapkit using a naturallanguage(human input)
		searchRequest.naturalLanguageQuery = addressTextfield.text ?? "Pizza" // use textfield as input
		
		searchRequest.region = mapView.region // search in the area you are currently in
		
		let mapSearch = MKLocalSearch(request: searchRequest)
		
		mapSearch.start { (searchResponse, error) in
			if error != nil{ //check for errors
				print(error)
				return
			}
			else if searchResponse!.mapItems.count == 0 //check for response
			{
				print("No result found!")
			}
			else
			{
				for singleItem in searchResponse!.mapItems{
					//print(singleItem) // TEST RUN<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
					
					//now we can will display info on the map
					let annotation = MKPointAnnotation()
					annotation.coordinate = singleItem.placemark.coordinate
					annotation.title = singleItem.name ?? "No name"
					annotation.subtitle = singleItem.phoneNumber ?? "No number"
					
					
					
					self.mapView.addAnnotation(annotation)
					
					//TESTRUN<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
					
				}
			}
		}
		
		
		
		addressTextfield.resignFirstResponder() // turns keyboard off
		
	}
	
	
}





