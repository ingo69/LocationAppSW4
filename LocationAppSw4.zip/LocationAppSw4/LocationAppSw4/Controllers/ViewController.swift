//
//  ViewController.swift
//  LocationAppSw4
//
//  Created by Ingo Ngoyama on 2/20/18.
//  Copyright © 2018 IngoNgoyama. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

	
	@IBOutlet var homeButtons: [UIButton]!
	
	
    override func viewDidLoad() {
        super.viewDidLoad()

		for button in homeButtons{
			
			button.layer.borderColor = UIColor.gray.cgColor
				button.layer.borderWidth = 2.5
		}
		
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

	

}
